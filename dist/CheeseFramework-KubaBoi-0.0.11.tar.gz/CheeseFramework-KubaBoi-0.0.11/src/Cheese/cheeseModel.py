

class CheeseModel:
    pass